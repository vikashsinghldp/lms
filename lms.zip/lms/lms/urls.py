
from django.contrib import admin
from django.urls import path
from .import views
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views
from . import settings
urlpatterns = [
    path('admin/', admin.site.urls),
    path('base',views.BASE,name='base'),
    path('', views.home, name='home'),
    path('contact', views.contact, name='contact'),
    path('about', views.about, name='about'),
    path('courses', views.courses, name='courses'),
    path('course1', views.course1, name='course1'),
    path('ajax/login/', views.ajax_login, name='ajax_login'),
    path('ajax/signup/', views.ajax_signup, name='ajax_signup'),
    path('ajax/forgot-password/', views.ajax_forgot_password, name='ajax_forgot_password'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('logout/', views.logout_view, name='logout'),
    path("create-order/", views.create_order, name="create_order"),
    path("payment-success/", views.payment_success, name='payment_success'),
    path("course/<int:course_id>/lessons/", views.course_lessons, name="course_lessons"),
    path("course/<int:course_id>/doubts/", views.course_doubts, name="course_doubts"),
    path("course/<int:course_id>/ask-doubt/", views.ask_doubt, name="ask_doubt"),
    path("profile/settings/", views.profile_settings, name="profile_settings"),
    path("profile/", views.view_profile, name="view_profile"),
    path("course/<int:course_id>/resources/",views.course_resources,name="course_resources"),
    path('forgot-password/',
         auth_views.PasswordResetView.as_view(
             template_name='forgot_password.html'
         ),
         name='password_reset'),

    path('forgot-password/done/',
         auth_views.PasswordResetDoneView.as_view(
             template_name='password_reset_done.html'
         ),
         name='password_reset_done'),

    path('reset/<uidb64>/<token>/',
         auth_views.PasswordResetConfirmView.as_view(
             template_name='password_reset_confirm.html'
         ),
         name='password_reset_confirm'),

    path('reset/done/',
         auth_views.PasswordResetCompleteView.as_view(
             template_name='password_reset_complete.html'
         ),
         name='password_reset_complete'),


]

urlpatterns += static(
    settings.MEDIA_URL,
    document_root=settings.MEDIA_ROOT
)
